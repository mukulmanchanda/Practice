import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { data, data1 } from './dataClass';
import { HttpClient } from '@angular/common/http';
import { CATCH_ERROR_VAR } from '@angular/compiler/src/output/output_ast';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  private _url = './../assets/json/data.json';

  constructor(private http:HttpClient) { }

  getData(): Observable<data[]>{
    return this.http.get<data[]>(this._url)
  }
  setData(d : data1): Observable<any>{
    return this.http.put(this._url, d);
  }

}
