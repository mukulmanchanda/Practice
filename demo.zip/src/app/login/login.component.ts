import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router'
import { TableComponent } from '../table/table.component';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public userName;
  public password;

  constructor(private route: Router) { }

  ngOnInit(): void {
  }
  navigateHome() {
    window.sessionStorage.UserName= this.userName;
    // window.sessionStorage.setItem("lastname", "Smith");
    // this.route.navigateByUrl('/home');
  }


}
