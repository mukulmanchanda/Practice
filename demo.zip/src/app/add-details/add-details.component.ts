import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { DataService } from '../data.service';
import { data, data1 } from '../dataClass';

@Component({
  selector: 'app-add-details',
  templateUrl: './add-details.component.html',
  styleUrls: ['./add-details.component.scss']
})
export class AddDetailsComponent implements OnInit {

  uploadData: FormGroup;
  onj: data1;
  

  constructor(public dataService : DataService, public fb: FormBuilder,) { 
    this.uploadData = this.fb.group({
      name: [''],
      age: [null]
    })
  }

  details = [{name:'' ,age : null}];
  ngOnInit(): void {

 

  }



  save(a,b): void {
    // this.dataService.setData(this.details).subscribe(d => this.details.name = d.name)
    console.log(a.value,b.value);
    // this.details.push(a.value , b.value)
    
    console.log(this.details);
    // h.updateHero(this.hero)
    //   .subscribe(() => this.goBack());
    // let formData: any = new FormData();
    // formData.append("name", this.uploadData.get('name').value);
    // formData.append("age", this.uploadData.get('age').value);
    // this.dataService.setData(formData).subscribe();

    var dd = new data1();
dd.name= this.uploadData.get('name').value;
dd.age= this.uploadData.get('age').value;

this.dataService.setData(dd).subscribe(d=> this.onj =d);
console.log(this.onj);

  }

}
