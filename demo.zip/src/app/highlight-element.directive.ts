import { Directive, ElementRef, Host, HostListener, Input, OnInit } from '@angular/core';

@Directive({
  selector: '[appHighlightElement]'
})
export class HighlightElementDirective implements OnInit {

  constructor(private element: ElementRef) { }

  @Input() Color: string;
  @HostListener('click') click() {
    this.element.nativeElement.style.backgroundColor = 'black';
  }

  @HostListener('mouseenter') m(){
    this.element.nativeElement.style.boxShadow = '0 20px 50px rgba(8, 112, 184, 0.7)'
  }
  @HostListener('mouseleave') m2(){
    this.element.nativeElement.style.boxShadow = 'none'
  }
ngOnInit() {
  this.element.nativeElement.style.color = this.Color;
}

}
