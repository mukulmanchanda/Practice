import { HighlightElementDirective } from './highlight-element.directive';

describe('HighlightElementDirective', () => {
  it('should create an instance', () => {
    const directive = new HighlightElementDirective();
    expect(directive).toBeTruthy();
  });
});
