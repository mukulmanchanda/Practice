import { AfterViewInit, Component, OnChanges, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { TableComponent } from '../table/table.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit,OnChanges,AfterViewInit {

 public search;
 public date = new Date();
 @ViewChild(TableComponent, {static:true})
 Table :TableComponent;
  constructor(private route: Router) { }

  ngOnInit(): void {
document.getElementById('Name1').innerHTML = window.sessionStorage.UserName;
  }
  clearSelection () {
this.search = '';
  }
  navigate1 () {
    this.route.navigateByUrl('/addDetails');
  }
  ngOnChanges ( ) {
    alert('yoyo');
    
  }
  ngAfterViewInit(){
    setTimeout(()=> {
      this.Table.clearB.nativeElement.innerHTML= 'Clear Man';
    },10 );
  }

}
