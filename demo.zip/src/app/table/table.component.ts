import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { DataService } from '../data.service';
import { data } from '../dataClass';


@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit {

  @Input()
  searchName;
  @Output() clearSelection = new EventEmitter<boolean>();
  @ViewChild('clearB') clearB: ElementRef;

  public details: Array<data> = new Array();

  constructor(private dataService: DataService) {
    // this.details = data;
    // dataService.getData().subscribe(d => this.details = d);

    this.details.push({ name: "mukul", age: 12 },
      { name: "rahul", age: 22 }
    )

  }


  //   data =[

  //     {name :'Mukul', age :12},
  //     // {name :'Rahul', age:22},
  //     // {name :'Vineet', age:22}
  // ]
  
  ngOnInit(): void {
    this.dataService.getData().subscribe(d => this.details = d);
  }
  clear() {
    this.clearSelection.emit(true); 
  }

  ngOnChanges() {
    if (this.searchName !== '') {
      this.details = this.details.filter(d => {
        return d.name.toLowerCase().match(this.searchName.toLowerCase())
      })
    } else {

    }
  }

}
