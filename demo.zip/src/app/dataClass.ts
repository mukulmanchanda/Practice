export interface data {
     name:string ;
     age: number ;    
}

export class data1 {
    name:string ;
    age: number ;    
}