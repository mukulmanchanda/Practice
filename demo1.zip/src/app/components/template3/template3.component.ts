import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-template3',
  templateUrl: './template3.component.html',
  styleUrls: ['./template3.component.css']
})
export class Template3Component implements OnInit {

  @Input() data;
  constructor() { }

  ngOnInit(): void {
  }

}
