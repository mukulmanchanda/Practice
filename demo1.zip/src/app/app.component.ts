import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo1';
  
  list = [{name:'template one', color:'blue'},
  {name:'template two', color:'red'},
  {name:'template three', color:'green'},]

}
